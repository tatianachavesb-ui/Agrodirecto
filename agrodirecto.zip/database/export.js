// Genera database/agrodirecto_export.sql (estructura + datos) para entregar a la profe.
const Database = require('better-sqlite3'), fs = require('fs'), path = require('path');
const db = new Database(path.join(__dirname, '..', 'agrodirecto.db'));
let out = '-- Export de la base de datos AgroDirecto\nBEGIN;\n';
for (const t of db.prepare("SELECT name, sql FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'").all()) {
  out += t.sql + ';\n';
  for (const r of db.prepare(`SELECT * FROM ${t.name}`).all()) {
    const v = Object.values(r).map(x => x === null ? 'NULL' : typeof x === 'number' ? x : `'${String(x).replace(/'/g, "''")}'`);
    out += `INSERT INTO ${t.name} VALUES (${v.join(', ')});\n`;
  }
}
fs.writeFileSync(path.join(__dirname, 'agrodirecto_export.sql'), out + 'COMMIT;\n');
console.log('Listo: database/agrodirecto_export.sql');
