-- Modelo de datos de AgroDirecto (SQLite). 4 tablas relacionadas.
CREATE TABLE IF NOT EXISTS usuarios (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  nombre TEXT NOT NULL,
  correo TEXT NOT NULL UNIQUE,
  telefono TEXT NOT NULL,
  password_hash TEXT NOT NULL,
  rol TEXT NOT NULL CHECK (rol IN ('comprador','gestor'))
);
CREATE TABLE IF NOT EXISTS productos (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  gestor_id INTEGER NOT NULL REFERENCES usuarios(id),
  nombre TEXT NOT NULL,
  productor TEXT NOT NULL,
  municipio TEXT NOT NULL,
  categoria TEXT NOT NULL,
  unidad TEXT NOT NULL,
  precio INTEGER NOT NULL CHECK (precio > 0),
  precio_referencia INTEGER NOT NULL CHECK (precio_referencia > 0),
  pct_productor INTEGER NOT NULL DEFAULT 90 CHECK (pct_productor BETWEEN 1 AND 100),
  stock INTEGER NOT NULL CHECK (stock >= 0),
  descripcion TEXT
);
CREATE TABLE IF NOT EXISTS pedidos (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  comprador_id INTEGER NOT NULL REFERENCES usuarios(id),
  fecha TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  telefono TEXT NOT NULL,
  direccion TEXT NOT NULL,
  total INTEGER NOT NULL,
  estado TEXT NOT NULL DEFAULT 'pendiente'
);
CREATE TABLE IF NOT EXISTS detalle_pedido (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  pedido_id INTEGER NOT NULL REFERENCES pedidos(id),
  producto_id INTEGER NOT NULL REFERENCES productos(id),
  cantidad INTEGER NOT NULL CHECK (cantidad > 0),
  precio_unitario INTEGER NOT NULL
);
