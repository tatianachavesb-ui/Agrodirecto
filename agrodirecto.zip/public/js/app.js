// AgroDirecto: front-end de una sola página (HTML5 + Bootstrap + JavaScript).
// Cada "vista" es una función; el enrutador lee el # de la URL (mapa de navegación).
const app = document.getElementById('app');
const money = n => '$' + Number(n).toLocaleString('es-CO');
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
let user = null, cart = JSON.parse(localStorage.getItem('cart') || '[]');
const saveCart = () => { localStorage.setItem('cart', JSON.stringify(cart)); drawNav(); };

async function api(url, method = 'GET', body) {
  const r = await fetch('/api' + url, { method, headers: { 'Content-Type': 'application/json' }, body: body && JSON.stringify(body) });
  const d = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(d.error || 'Algo salió mal.');
  return d;
}
const msg = (id, text, ok) => { const e = document.getElementById(id); e.className = ok ? 'ahorro' : 'error'; e.textContent = text; };

function drawNav() {
  const n = cart.reduce((a, i) => a + i.cantidad, 0);
  document.getElementById('nav').innerHTML =
    `<a href="#/">Catálogo</a><a href="#/carrito">Carrito (${n})</a>` +
    (user ? (user.rol === 'gestor' ? '<a href="#/gestor">Mi panel</a>' : '') +
            '<a href="#/pedidos">Pedidos</a>' + `<span>Hola, ${esc(user.nombre.split(' ')[0])}</span><button class="btn btn-link" id="salir">Salir</button>`
          : '<a href="#/ingresar">Ingresar</a><a href="#/registro">Crear cuenta</a>');
  const s = document.getElementById('salir');
  if (s) s.onclick = async () => { await api('/logout', 'POST'); user = null; drawNav(); location.hash = '#/'; };
}

// Barra del "precio justo": cuánto del pago llega al productor
function precioJusto(p) {
  const aProd = Math.round(p.precio * p.pct_productor / 100), ahorro = Math.round((1 - p.precio / p.precio_referencia) * 100);
  return `<div class="split" role="img" aria-label="De ${money(p.precio)}, ${money(aProd)} llegan al productor (${p.pct_productor}%)">
      <span class="prod" style="width:${p.pct_productor}%">Productor ${p.pct_productor}%</span><span class="gest" style="width:${100 - p.pct_productor}%"></span></div>
    <p class="small mb-0 mt-1">Al productor: <strong>${money(aProd)}</strong>. En tienda convencional: <span class="tachado">${money(p.precio_referencia)}</span>
    <span class="ahorro">(ahorras ${ahorro}%)</span></p>`;
}

// ---------- Vistas ----------
async function vistaCatalogo() {
  app.innerHTML = `<div class="hero"><h1>Del campo a tu mesa, sin intermediarios</h1><p class="lead mb-0">Mira cuánto de tu pago llega a quien cultivó.</p></div>
    <form id="filtro" class="row g-2 mb-4" role="search"><div class="col-md-6"><label for="q">Buscar producto o productor</label><input id="q" class="form-control"></div>
    <div class="col-md-4"><label for="cat">Categoría</label><select id="cat" class="form-select"><option value="">Todas</option>
    ${['Verduras','Frutas','Tubérculos','Huevos y lácteos','Despensa','Otros'].map(c => `<option>${c}</option>`).join('')}</select></div></form>
    <div class="row g-3" id="lista" aria-live="polite"></div>`;
  const cargar = async () => {
    const ps = await api(`/productos?q=${encodeURIComponent(q.value)}&categoria=${encodeURIComponent(cat.value)}`);
    lista.innerHTML = ps.length ? ps.map(p => `<div class="col-sm-6 col-lg-4"><article class="card-prod p-3">
      <h2 class="h5"><a href="#/producto/${p.id}">${esc(p.nombre)}</a></h2>
      <p class="small mb-2">${esc(p.productor)} · ${esc(p.municipio)}</p>
      <p class="mb-2"><span class="precio">${money(p.precio)}</span> <span class="small">por ${esc(p.unidad)}</span></p>${precioJusto(p)}</article></div>`).join('')
      : '<p>No encontramos productos con ese filtro. Prueba con otra palabra.</p>';
  };
  q.oninput = cat.onchange = cargar; filtro.onsubmit = e => e.preventDefault(); cargar();
}

async function vistaProducto(id) {
  let p; try { p = await api('/productos/' + id); } catch (e) { app.innerHTML = `<p class="error">${esc(e.message)}</p>`; return; }
  app.innerHTML = `<a href="#/">← Volver al catálogo</a><h1 class="mt-2">${esc(p.nombre)}</h1>
    <p>${esc(p.productor)} · ${esc(p.municipio)} · ${esc(p.categoria)}</p><p>${esc(p.descripcion)}</p>
    <p><span class="precio">${money(p.precio)}</span> por ${esc(p.unidad)} · quedan ${p.stock}</p>
    <div style="max-width:480px" class="mb-3"><h2 class="h6">¿Cuánto llega al productor?</h2>${precioJusto(p)}</div>
    <div class="d-flex gap-2 align-items-end"><div><label for="cant">Cantidad</label><input id="cant" type="number" min="1" max="${p.stock}" value="1" class="form-control" style="width:6rem"></div>
    <button id="add" class="btn btn-agro" ${p.stock ? '' : 'disabled'}>Agregar al carrito</button></div><p id="m" role="status"></p>`;
  add.onclick = () => {
    const c = Number(cant.value);
    if (!Number.isInteger(c) || c < 1 || c > p.stock) return msg('m', `Escribe una cantidad entera entre 1 y ${p.stock}.`);
    const i = cart.find(x => x.id === p.id);
    i ? i.cantidad = Math.min(p.stock, i.cantidad + c) : cart.push({ id: p.id, nombre: p.nombre, precio: p.precio, cantidad: c });
    saveCart(); msg('m', 'Agregado al carrito.', true);
  };
}

function vistaCarrito() {
  const total = cart.reduce((a, i) => a + i.precio * i.cantidad, 0);
  if (!cart.length) { app.innerHTML = '<h1>Tu carrito</h1><p>Aún no tienes productos. <a href="#/">Ve al catálogo</a>.</p>'; return; }
  app.innerHTML = `<h1>Tu carrito</h1><ul class="list-group mb-3">${cart.map((i, k) =>
    `<li class="list-group-item d-flex justify-content-between align-items-center">${esc(i.nombre)} × ${i.cantidad}
    <span>${money(i.precio * i.cantidad)} <button class="btn btn-sm btn-outline-dark ms-2" data-k="${k}" aria-label="Quitar ${esc(i.nombre)}">Quitar</button></span></li>`).join('')}</ul>
    <p class="h4">Total: ${money(total)}</p><h2 class="h5 mt-4">Datos de entrega (el pago es simulado)</h2>
    <form id="f" class="row g-3" style="max-width:600px" novalidate>
    <div class="col-12"><label for="tel">Teléfono (solo números)</label><input id="tel" class="form-control" inputmode="numeric" pattern="\\d{7,10}" required></div>
    <div class="col-12"><label for="dir">Dirección de entrega</label><input id="dir" class="form-control" minlength="6" required></div>
    <div class="col-12"><button class="btn btn-agro">Confirmar pedido</button></div></form><p id="m" role="status"></p>`;
  document.querySelectorAll('[data-k]').forEach(b => b.onclick = () => { cart.splice(b.dataset.k, 1); saveCart(); vistaCarrito(); });
  f.onsubmit = async e => {
    e.preventDefault();
    if (!user) return msg('m', 'Inicia sesión como comprador para pedir.');
    if (!/^\d{7,10}$/.test(tel.value)) return msg('m', 'El teléfono solo puede tener números (7 a 10 dígitos).');
    try { const r = await api('/pedidos', 'POST', { items: cart, telefono: tel.value, direccion: dir.value }); cart = []; saveCart();
      app.innerHTML = `<h1>Pedido #${r.id} recibido</h1><p>El gestor coordinará la entrega. <a href="#/pedidos">Ver mis pedidos</a>.</p>`;
    } catch (err) { msg('m', err.message); }
  };
}

function vistaIngresar(registro) {
  app.innerHTML = `<h1>${registro ? 'Crear cuenta' : 'Ingresar'}</h1><form id="f" class="row g-3" style="max-width:520px" novalidate>
    ${registro ? `<div class="col-12"><label for="nombre">Nombre (solo letras)</label><input id="nombre" class="form-control" required></div>
    <div class="col-12"><label for="tel">Teléfono (solo números)</label><input id="tel" class="form-control" inputmode="numeric" required></div>
    <div class="col-12"><label for="rol">Tipo de cuenta</label><select id="rol" class="form-select"><option value="comprador">Comprador</option><option value="gestor">Gestor o asociación de productores</option></select></div>` : ''}
    <div class="col-12"><label for="correo">Correo</label><input id="correo" type="email" class="form-control" required></div>
    <div class="col-12"><label for="pass">Contraseña${registro ? ' (mínimo 8 caracteres)' : ''}</label><input id="pass" type="password" class="form-control" required></div>
    <div class="col-12"><button class="btn btn-agro">${registro ? 'Crear cuenta' : 'Entrar'}</button></div></form><p id="m" role="alert"></p>
    ${registro ? '' : '<p class="small">Prueba: gestor@demo.co / Demo12345</p>'}`;
  f.onsubmit = async e => {
    e.preventDefault();
    if (registro) {
      if (!/^[A-Za-zÁÉÍÓÚÜáéíóúüÑñ .,'-]{3,80}$/.test(nombre.value)) return msg('m', 'El nombre solo puede tener letras (mínimo 3).');
      if (!/^\d{7,10}$/.test(tel.value)) return msg('m', 'El teléfono solo puede tener números (7 a 10 dígitos).');
      if (pass.value.length < 8) return msg('m', 'La contraseña debe tener mínimo 8 caracteres.');
    }
    try { user = await api(registro ? '/registro' : '/login', 'POST', { nombre: registro && nombre.value, telefono: registro && tel.value,
        rol: registro && rol.value, correo: correo.value, password: pass.value });
      drawNav(); location.hash = user.rol === 'gestor' ? '#/gestor' : '#/';
    } catch (err) { msg('m', err.message); }
  };
}

async function vistaGestor() {
  if (!user || user.rol !== 'gestor') { app.innerHTML = '<p class="error">Esta sección es solo para gestores. <a href="#/ingresar">Ingresar</a></p>'; return; }
  const campo = (id, et, extra = '') => `<div class="col-md-6"><label for="${id}">${et}</label><input id="${id}" class="form-control" ${extra} required></div>`;
  app.innerHTML = `<h1>Panel del gestor</h1><h2 class="h5">Publicar un producto</h2><form id="f" class="row g-3 mb-4" novalidate>
    ${campo('nombre','Producto (solo letras)')}${campo('productor','Productor (solo letras)')}${campo('municipio','Municipio (solo letras)')}
    <div class="col-md-6"><label for="categoria">Categoría</label><select id="categoria" class="form-select"><option>Verduras</option><option>Frutas</option><option>Tubérculos</option><option>Huevos y lácteos</option><option>Despensa</option><option>Otros</option></select></div>
    ${campo('unidad','Unidad (kg, atado, cubeta…)')}${campo('precio','Precio por unidad (pesos)','type="number" min="1"')}
    ${campo('ref','Precio en tienda convencional (pesos)','type="number" min="1"')}${campo('pct','% del precio que llega al productor','type="number" min="1" max="100" value="90"')}
    ${campo('stock','Cantidad disponible','type="number" min="0"')}
    <div class="col-12"><label for="desc">Descripción</label><input id="desc" class="form-control" maxlength="200"></div>
    <div class="col-12"><button class="btn btn-agro">Publicar producto</button></div></form><p id="m" role="status"></p>
    <h2 class="h5">Mis productos</h2><div id="mios"></div>`;
  const listar = async () => { const ps = await api('/productos?mios=1');
    mios.innerHTML = ps.length ? `<ul class="list-group">${ps.map(p => `<li class="list-group-item">${esc(p.nombre)} · ${esc(p.productor)} · ${money(p.precio)} · quedan ${p.stock}</li>`).join('')}</ul>` : '<p>Aún no has publicado productos.</p>'; };
  f.onsubmit = async e => {
    e.preventDefault();
    const re = /^[A-Za-zÁÉÍÓÚÜáéíóúüÑñ .,'-]{3,80}$/;
    if (![nombre, productor, municipio].every(i => re.test(i.value))) return msg('m', 'Producto, productor y municipio solo pueden tener letras.');
    try { await api('/productos', 'POST', { nombre: nombre.value, productor: productor.value, municipio: municipio.value, categoria: categoria.value,
        unidad: unidad.value, precio: precio.value, precio_referencia: ref.value, pct_productor: pct.value, stock: stock.value, descripcion: desc.value });
      f.reset(); msg('m', 'Producto publicado.', true); listar();
    } catch (err) { msg('m', err.message); }
  };
  listar();
}

async function vistaPedidos() {
  if (!user) { app.innerHTML = '<p class="error">Inicia sesión para ver tus pedidos. <a href="#/ingresar">Ingresar</a></p>'; return; }
  const ps = await api('/pedidos');
  app.innerHTML = `<h1>${user.rol === 'gestor' ? 'Pedidos de tus productos' : 'Mis pedidos'}</h1>` + (ps.length
    ? `<div class="table-responsive"><table class="table"><thead><tr><th>Pedido</th><th>Fecha</th><th>Producto</th><th>Cantidad</th><th>Total</th><th>Estado</th></tr></thead><tbody>${ps.map(p =>
      `<tr><td>#${p.id}</td><td>${esc(p.fecha)}</td><td>${esc(p.producto)}</td><td>${p.cantidad}</td><td>${money(p.total)}</td><td>${esc(p.estado)}</td></tr>`).join('')}</tbody></table></div>`
    : '<p>Todavía no hay pedidos.</p>');
}

// ---------- Enrutador ----------
async function ruta() {
  const [, r, id] = (location.hash || '#/').split('/');
  const vistas = { '': vistaCatalogo, producto: () => vistaProducto(id), carrito: vistaCarrito, ingresar: () => vistaIngresar(false),
    registro: () => vistaIngresar(true), gestor: vistaGestor, pedidos: vistaPedidos };
  try { await (vistas[r] || vistaCatalogo)(); } catch (e) { app.innerHTML = `<p class="error">${esc(e.message)}</p>`; }
  app.focus();
}
window.addEventListener('hashchange', ruta);
(async () => { try { user = await api('/yo'); } catch {} drawNav(); ruta(); })();
